Arquivo zip gerado em: 29/11/2021 15:42:28 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 2 - Arvore AVL de jogos

Casos de teste do 4 ao 6 -> CSV-SemRep.csv
Casos de teste 1 ao 3 e 6 ao 7 -> CSV-TodosJogos.csv
