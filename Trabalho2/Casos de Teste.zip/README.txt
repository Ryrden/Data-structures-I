Arquivo zip gerado em: 29/11/2021 15:42:28 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 2 - Arvore AVL de jogos